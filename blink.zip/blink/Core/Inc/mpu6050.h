#ifndef MPU6050_H
#define MPU6050_H

#include "main.h"
#include <stdint.h>

/* Dirección I2C del MPU6050
 * AD0 pin -> según esquemático va a GND (ADO conectado a GND en U5)
 * por lo tanto dirección = 0x68 << 1 = 0xD0 */
#define MPU6050_ADDR        (0x68 << 1)

/* Registros principales */
#define MPU6050_REG_PWR_MGMT_1   0x6B
#define MPU6050_REG_SMPLRT_DIV   0x19
#define MPU6050_REG_CONFIG       0x1A
#define MPU6050_REG_GYRO_CONFIG  0x1B
#define MPU6050_REG_ACCEL_CONFIG 0x1C
#define MPU6050_REG_ACCEL_XOUT_H 0x3B
#define MPU6050_REG_TEMP_OUT_H   0x41
#define MPU6050_REG_GYRO_XOUT_H  0x43
#define MPU6050_REG_WHO_AM_I     0x75

/* Escalas del acelerómetro */
typedef enum {
    ACCEL_SCALE_2G  = 0x00,
    ACCEL_SCALE_4G  = 0x08,
    ACCEL_SCALE_8G  = 0x10,
    ACCEL_SCALE_16G = 0x18
} MPU6050_AccelScale;

/* Escalas del giroscopio */
typedef enum {
    GYRO_SCALE_250DPS  = 0x00,
    GYRO_SCALE_500DPS  = 0x08,
    GYRO_SCALE_1000DPS = 0x10,
    GYRO_SCALE_2000DPS = 0x18
} MPU6050_GyroScale;

/* Estructura con todos los datos */
typedef struct {
    float accel_x;   // m/s²
    float accel_y;
    float accel_z;
    float gyro_x;    // °/s
    float gyro_y;
    float gyro_z;
    float temp_c;    // °C
    int16_t raw_ax, raw_ay, raw_az;
    int16_t raw_gx, raw_gy, raw_gz;
} MPU6050_Data;

/* Funciones públicas */
HAL_StatusTypeDef MPU6050_Init(I2C_HandleTypeDef *hi2c,
                                MPU6050_AccelScale ascale,
                                MPU6050_GyroScale  gscale);
HAL_StatusTypeDef MPU6050_ReadAll(I2C_HandleTypeDef *hi2c, MPU6050_Data *data);
HAL_StatusTypeDef MPU6050_WhoAmI(I2C_HandleTypeDef *hi2c, uint8_t *id);

#endif /* MPU6050_H */
